<?php

class Produk {
	public $judul, 
		   $penulis,
		   $penerbit,
		   $harga,
		   $jlmHalaman,
		   $waktuMain,
		   $tipe;
	
	public function __construct( $judul = "judul", $penulis = "penulis", $penerbit = "penerbit", $harga = 0, $jlmHalaman = 0, $waktuMain = 0, $tipe ) {
 		$this->judul = $judul;
		$this->penulis = $penulis;
		$this->penerbit = $penerbit;
		$this->harga = $harga;
		$this->jlmHalaman = $jlmHalaman;
		$this->waktuMain = $waktuMain;
		$this->tipe = $tipe;
	}
	
	public function getLabel() {
		return "$this->judul, $this->penulis, $this->penerbit";	
	}
	
	public function getInfoLengkap() {
		$str = "{$this->tipe} : {$this->judul} | {$this->getLabel()} (Rp. {$this->harga})";
		if( $this->tipe == "Komik" ) {
			$str .= " - {$this->jlmHalaman} Halaman.";
		} else if( $this->tipe == "Game" ) {
			$str .= " ~ {$this->waktuMain} Jam.";
		}
		
		return $str;
		
	}
	
}


class CetakInfoProduk {
	public function cetak( Produk $produk ) {
		$str = "{$produk->judul} | {$produk->getLabel()} (Rp. {$produk->harga})";
		return $str;
	}
}



$produk1 = new Produk("Boruto", "Saburo", "Bayu", 45000, 200, 0, "Komik");
$produk2 = new Produk("Among Us", "Saburoto", "Bayuwanita", 67000, 0, 50, "Game");

echo $produk1->getInfoLengkap();
echo  "<br>";
echo $produk2->getInfoLengkap();


 




