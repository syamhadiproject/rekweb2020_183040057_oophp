<?php 

class Coba {
	public function __construct() 
	{
		echo "Welcome To My Youtube Channel";
	}
		
}