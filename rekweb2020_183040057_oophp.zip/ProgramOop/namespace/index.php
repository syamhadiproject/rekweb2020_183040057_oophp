<?php

require_once 'App/init.php';

/*
$produk1 = new Komik("Boruto", "Saburo", "Bayu", 45000, 200);
$produk2 = new Game("Among Us", "Saburoto", "Bayuwanita", 67000, 50);


$cetakProduk = new CetakInfoProduk();
$cetakProduk->tambahProduk( $produk1 );
$cetakProduk->tambahProduk(  $produk2 );
echo $cetakProduk->cetak();

echo "<hr>"; 
*/

use App\Service\User as ServiceUser;
use App\Produk\User as ProdukUser ;

new ServiceUser();
echo "<br>"; 
new ProdukUser();